﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public delegate void PlayerAction();
public delegate void PlayerActionDirection(Vector2 direction);
public interface IPlayerInput
{
    event PlayerAction JumpInput;
    event PlayerActionDirection MoveInput;
}

public delegate void EnemyActions();
public delegate void EnemyMovePattern(Vector2 direction);
public interface IEnemy
{
    event EnemyActions EnemyAction;
    event EnemyMovePattern MoveEnemy;
}