﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class NormalEnemyMove : MonoBehaviour
{
    private NavMeshAgent enemyAgent;
    private GameObject player;
    // Start is called before the first frame update
    void Start()
    {
        enemyAgent = this.gameObject.GetComponent<NavMeshAgent>();
        player = GameObject.Find("Player");
    }

    // Update is called once per frame
    void Update()
    {
        enemyAgent.SetDestination(player.transform.position);
    }
}
