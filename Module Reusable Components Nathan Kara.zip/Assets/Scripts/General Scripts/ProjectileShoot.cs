﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ProjectileShoot : MonoBehaviour
{
    [HideInInspector] public GameObject projectile;
    [HideInInspector] public bool shootProjectile;
    float shootCoolDown;
    [HideInInspector] public bool isSpreadShot;
    public GameObject spawnPosition;
    public Projectile projectileObject;
    // Start is called before the first frame update
    void Start()
    {
        spawnPosition = GameObject.Find("ProjectilePoint");
        projectile = projectileObject.projectile;
        shootCoolDown = 0;
        shootProjectile = true;
    }

    // Update is called once per frame
    void Update()
    {
       if(shootCoolDown > 0)
        {
            shootProjectile = false;
            shootCoolDown -= Time.deltaTime;
        }
    }
    public void Shoot()
    {

        if (shootProjectile)
        {
            Debug.Log("Shot projectile");
            //shoot projectile
            Instantiate(projectile, spawnPosition.transform);
            shootCoolDown = 0.5f;
            /*if (isSpreadShot)
            {
                //shoot spreadshot projectile
            }
            else
            {
               
            }*/

        }
        /*if(shootInput){
         shootProjectile = true;


        }*/
    }
}
