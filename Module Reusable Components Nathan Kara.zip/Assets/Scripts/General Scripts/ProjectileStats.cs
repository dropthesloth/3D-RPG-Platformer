﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ProjectileStats : MonoBehaviour
{ 
    public Projectile projectileObject;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        gameObject.transform.position += Vector3.forward * projectileObject.speed;
    }
    private void OnCollisionEnter(Collision collision)
    {
        if(collision.gameObject.tag != gameObject.tag)
        {
            if (collision.gameObject.tag == "Player" || collision.gameObject.tag == "Enemy")            
            collision.gameObject.GetComponent<Stats>().health -= projectileObject.damage;
        }
        
    }
}
