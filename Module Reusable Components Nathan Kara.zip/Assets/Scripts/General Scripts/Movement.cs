﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Movement : MonoBehaviour
{
    public Transform movingObject;
    private Rigidbody rb;
    public float speed;
    public float movementX;
    public float movementZ;
    // Start is called before the first frame update
    void Start()
    {
        rb = gameObject.GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {       
        //this.gameObject.transform.position += new Vector3 (movementX * speed, 0, movementZ * speed);
        //rb.position += new Vector3(movementX * speed, 0, movementZ * speed);
    }
    public void Move(Vector2 direction)
    {
        rb.velocity = new Vector3(direction.x * speed, rb.velocity.y, direction.y * speed);
    }
}
