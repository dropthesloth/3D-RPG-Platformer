﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerInputController : MonoBehaviour, IPlayerInput
{
    //public PlayerJump jumpRef;
    [HideInInspector] public float movementX;
    [HideInInspector] public float movementZ;
    public bool abilityReady;
    public float abilityCooldown;
    public event PlayerActionDirection MoveInput = delegate { };
    public event PlayerAction JumpInput = delegate { };
    public event PlayerAction ShootInput = delegate { };
    public event PlayerAction WindJumpInput = delegate { };
    public event PlayerAction FlameDashInput = delegate { };
    // Start is called before the first frame update
    void Awake()
    {

        abilityReady = false;
        abilityCooldown = 0f;
    }

    // Update is called once per frame
    void Update()
    {
        if (MoveInput != null)
        {
            movementX = Input.GetAxis("Horizontal");
            movementZ = Input.GetAxis("Vertical");
            Vector2 direction = new Vector2(movementX, movementZ);
            MoveInput(direction);
        }
        if (Input.GetButtonDown("Jump") && JumpInput != null)
        {
            JumpInput();
        }
        if (Input.GetButtonDown("Ability") && abilityReady && WindJumpInput != null)
        {
            WindJumpInput();
            Debug.Log("AIr JUmp");
            abilityCooldown = 4f;
        }
        if (Input.GetButtonDown("Ability2") && abilityReady && FlameDashInput != null)
        {
            FlameDashInput();
            abilityCooldown = 3f;
        }
        if (Input.GetButtonDown("Fire") && ShootInput != null)
        {
            Debug.Log("Shoot!");
            ShootInput();
        }
    }
}

