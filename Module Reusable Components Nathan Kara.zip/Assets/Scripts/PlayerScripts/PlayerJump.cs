﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerJump : MonoBehaviour
{
    [HideInInspector]public Rigidbody rb;
    public float jumpForce;
    public bool isGrounded;
    // Start is called before the first frame update
    void Start()
    {
        rb = gameObject.GetComponent<Rigidbody>();
        isGrounded = true;
    }

    // Update is called once per frame
    void Update()
    {
      
    }  
    public void Jump()
    {
        if (isGrounded) 
        { 
            rb.velocity = Vector3.up * jumpForce;
            isGrounded = false;
        }
    }
}
