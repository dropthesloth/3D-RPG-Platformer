﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    [HideInInspector]public bool hasDoubleJump;
    PlayerJump playerJumpRef;
    PlayerInputKeyboard playerInput;
    PlayerInputController playerInputC;
    WindJump windJumpRef;
    FlameDash flameDashRef;
    ProjectileShoot projectileShootRef;
    [SerializeField] GameObject menu;
    Movement movementRef;
    private void Awake()
    {
        playerInput = GetComponent<PlayerInputKeyboard>();
        movementRef = GetComponent<Movement>();
        playerJumpRef = GetComponent<PlayerJump>();
        playerInput.MoveInput += movementRef.Move;
        playerInput.JumpInput += playerJumpRef.Jump;
    }

    // Update is called once per frame
    void Update()
    {
        if (playerJumpRef.isGrounded == false)
        {
            //Checks if the player can Wind Jump
            if (GetComponent<WindJump>()) 
            {
                if (windJumpRef.canWindJump)
                {
                    /*if (GetComponent<PlayerInputController>() && playerInputC.abilityReady)
                        Debug.Log("Testing testing");//playerInputC.abilityReady = false;
                    else if (GetComponent<PlayerInputKeyboard>())
                        playerInput.abilityReady = false;
                }
                else
                {*/
                    if (GetComponent<PlayerInputController>())
                        playerInputC.abilityReady = true;
                    else if (GetComponent<PlayerInputKeyboard>())
                        playerInput.abilityReady = true;
                }
            }
        }
 
            /*if (GetComponent<FlameDash>()){
            if (flameDashRef.dashTimer < 0) 
                { 
                if (GetComponent<PlayerInputController>())
                    Debug.Log("Testing testing");//playerInputC.abilityReady = false;
                else if (GetComponent<PlayerInputKeyboard>())
                    playerInput.abilityReady = false;
                }
            }
        }*/
    }
    public void ControllerInput()
    {
        if (GetComponent<PlayerInputKeyboard>())
        { 
        playerInputC = gameObject.AddComponent<PlayerInputController>();
        Destroy(playerInput);
        playerInput.MoveInput -= movementRef.Move;
        playerInput.JumpInput -= playerJumpRef.Jump;
        playerInputC.MoveInput += movementRef.Move;
        playerInputC.JumpInput += playerJumpRef.Jump;
            if (GetComponent<WindJump>())
                playerInputC.WindJumpInput += windJumpRef.DoubleJump;
            menu.SetActive(false);
        }

    }
    public void KeyboardInput()
    {
        if (GetComponent<PlayerInputController>())
        {
            playerInput = gameObject.AddComponent<PlayerInputKeyboard>();
            Destroy(playerInputC);
            playerInputC.MoveInput -= movementRef.Move;
            playerInputC.JumpInput -= playerJumpRef.Jump;
            playerInput.MoveInput += movementRef.Move;
            playerInput.JumpInput += playerJumpRef.Jump;
            if (GetComponent<WindJump>())
                playerInput.WindJumpInput += windJumpRef.DoubleJump;
            menu.SetActive(false);
        }
    }
    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Floor"))
        {
            playerJumpRef.isGrounded = true;
            if (GetComponent<FlameDash>())
                flameDashRef.canDash = true;
            if (GetComponent<WindJump>())
                windJumpRef.canWindJump = true;
        }      
        if (other.CompareTag("DoubleJump"))
        {
            //Adds double jump/wind jump component to the player
            windJumpRef = gameObject.AddComponent<WindJump>();
            if (GetComponent<PlayerInputController>())
                playerInputC.WindJumpInput += windJumpRef.DoubleJump;
            else if(GetComponent<PlayerInputKeyboard>())
                playerInput.WindJumpInput += windJumpRef.DoubleJump;
            other.gameObject.SetActive(false);
        }
        if (other.CompareTag("FlameDash"))
        {
            //adds flame dash component to the player
            flameDashRef = gameObject.AddComponent<FlameDash>();
            if (GetComponent<PlayerInputController>())
                playerInputC.FlameDashInput += flameDashRef.Dash;
            else if (GetComponent<PlayerInputKeyboard>())
                playerInput.FlameDashInput += flameDashRef.Dash;
            other.gameObject.SetActive(false);
        }
        if (other.CompareTag("FireBall"))
        {   
            other.gameObject.SetActive(false);
            projectileShootRef = gameObject.AddComponent<ProjectileShoot>();
            if (GetComponent<PlayerInputController>())
                playerInputC.ShootInput += projectileShootRef.Shoot;
            else if (GetComponent<PlayerInputKeyboard>())
                playerInput.ShootInput += projectileShootRef.Shoot;
            //Give player fireball
        }
       
    }
}
